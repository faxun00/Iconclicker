package com.example.iconclicker

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.WindowManager
import org.opencv.android.OpenCVLoader
import org.opencv.android.Utils
import org.opencv.core.Core
import org.opencv.core.Mat
import org.opencv.core.Size
import org.opencv.imgproc.Imgproc
import java.io.File

class CaptureService : Service() {

    companion object {
        const val SCALE = 0.5          // perkecil gambar agar pencocokan cepat
        const val VERIFY_MS = 300L     // cek ulang ikon setiap 300 ms saat mengklik
    }

    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var worker: Thread? = null
    @Volatile private var stopFlag = false
    private var lastFrame: Mat? = null
    private var lastText = ""
    private var W = 0
    private var H = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) { stopSelf(); return START_NOT_STICKY }
        val code = intent.getIntExtra("code", 0)
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33)
            intent.getParcelableExtra("data", Intent::class.java)
        else @Suppress("DEPRECATION") intent.getParcelableExtra("data")
        val cps = intent.getDoubleExtra("cps", 10.0)
        val conf = intent.getDoubleExtra("conf", 0.8)

        startAsForeground("Memulai...")
        if (data == null) { stopSelf(); return START_NOT_STICKY }

        try {
            val wm = getSystemService(WindowManager::class.java)
            if (Build.VERSION.SDK_INT >= 30) {
                val b = wm.maximumWindowMetrics.bounds
                W = b.width(); H = b.height()
            } else {
                val m = DisplayMetrics()
                @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(m)
                W = m.widthPixels; H = m.heightPixels
            }
            val dpi = resources.displayMetrics.densityDpi

            val mgr = getSystemService(MediaProjectionManager::class.java)
            projection = mgr.getMediaProjection(code, data)
            projection!!.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { stopSelf() }
            }, Handler(Looper.getMainLooper()))

            reader = ImageReader.newInstance(W, H, PixelFormat.RGBA_8888, 2)
            display = projection!!.createVirtualDisplay(
                "iconclicker", W, H, dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                reader!!.surface, null, null
            )
            stopFlag = false
            worker = Thread { loop(cps, conf) }.also { it.start() }
        } catch (e: Exception) {
            update("Gagal: ${e.message}")
            stopSelf()
        }
        return START_NOT_STICKY
    }

    // Ambil frame terbaru. Jika layar statis (tidak ada frame baru), pakai frame terakhir.
    private fun latestGray(): Mat? {
        val img = reader?.acquireLatestImage()
        if (img != null) {
            try {
                val p = img.planes[0]
                val rowPad = p.rowStride - p.pixelStride * W
                val bmp = Bitmap.createBitmap(W + rowPad / p.pixelStride, H, Bitmap.Config.ARGB_8888)
                bmp.copyPixelsFromBuffer(p.buffer)
                val rgba = Mat(); Utils.bitmapToMat(bmp, rgba); bmp.recycle()
                val gray = Mat(); Imgproc.cvtColor(rgba, gray, Imgproc.COLOR_RGBA2GRAY)
                val small = Mat(); Imgproc.resize(gray, small, Size(), SCALE, SCALE, Imgproc.INTER_AREA)
                rgba.release(); gray.release()
                lastFrame?.release(); lastFrame = small
            } finally { img.close() }
        }
        return lastFrame
    }

    private fun loop(cps: Double, conf: Double) {
        if (!OpenCVLoader.initLocal()) { update("OpenCV gagal dimuat"); return }
        val bmp = BitmapFactory.decodeFile(File(filesDir, "icon.png").path)
        if (bmp == null) { update("Ikon tidak ditemukan"); return }
        val rgba = Mat(); Utils.bitmapToMat(bmp, rgba)
        val g = Mat(); Imgproc.cvtColor(rgba, g, Imgproc.COLOR_RGBA2GRAY)
        val tpl = Mat(); Imgproc.resize(g, tpl, Size(), SCALE, SCALE, Imgproc.INTER_AREA)
        val interval = (1000.0 / cps).toLong().coerceAtLeast(1L)

        while (!stopFlag) {
            val frame = latestGray()
            if (frame == null) { Thread.sleep(50); continue }
            if (tpl.cols() > frame.cols() || tpl.rows() > frame.rows()) {
                update("Ikon lebih besar dari layar"); break
            }
            val res = Mat()
            Imgproc.matchTemplate(frame, tpl, res, Imgproc.TM_CCOEFF_NORMED)
            val mm = Core.minMaxLoc(res); res.release()

            if (!(mm.maxVal >= conf)) {            // ikon tidak ada -> berhenti klik
                update("Menunggu ikon muncul...")
                Thread.sleep(150); continue
            }
            val click = ClickService.instance
            if (click == null) {
                update("Layanan aksesibilitas belum aktif")
                Thread.sleep(500); continue
            }
            val x = ((mm.maxLoc.x + tpl.cols() / 2.0) / SCALE).toFloat()
            val y = ((mm.maxLoc.y + tpl.rows() / 2.0) / SCALE).toFloat()
            update("Ikon terdeteksi - mengklik %.1fx/detik".format(cps))

            val end = SystemClock.elapsedRealtime() + VERIFY_MS
            var next = SystemClock.elapsedRealtime()
            while (!stopFlag && SystemClock.elapsedRealtime() < end) {
                click.tap(x, y)
                next += interval
                val d = next - SystemClock.elapsedRealtime()
                if (d > 0) Thread.sleep(d)
            }
        }
        rgba.release(); g.release(); tpl.release()
    }

    private fun startAsForeground(text: String) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("cap", "Icon Clicker", NotificationManager.IMPORTANCE_LOW))
        val n = buildNotif(text)
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(1, n)
    }

    private fun buildNotif(text: String): Notification =
        Notification.Builder(this, "cap")
            .setContentTitle("Icon Clicker aktif")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setOngoing(true)
            .build()

    private fun update(text: String) {
        if (text == lastText) return
        lastText = text
        getSystemService(NotificationManager::class.java).notify(1, buildNotif(text))
    }

    override fun onDestroy() {
        stopFlag = true
        worker?.join(500)
        display?.release()
        reader?.close()
        projection?.stop()
        lastFrame?.release()
        super.onDestroy()
    }
}
