package com.example.iconclicker

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.widget.*
import java.io.File

class MainActivity : Activity() {
    private lateinit var preview: ImageView
    private lateinit var status: TextView
    private lateinit var cps: EditText
    private lateinit var conf: EditText

    private val iconFile get() = File(filesDir, "icon.png")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }
        fun label(t: String) = TextView(this).apply { text = t }.also { root.addView(it) }
        fun button(t: String, f: () -> Unit) = Button(this).apply {
            text = t; setOnClickListener { f() }
        }.also { root.addView(it) }
        fun number(def: String) = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            setText(def)
        }.also { root.addView(it) }

        status = label("")
        button("1. Aktifkan layanan aksesibilitas") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        button("2. Upload ikon") {
            startActivityForResult(
                Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*" }, 1)
        }
        preview = ImageView(this).apply {
            layoutParams = LinearLayout.LayoutParams(-1, (120 * resources.displayMetrics.density).toInt())
            scaleType = ImageView.ScaleType.FIT_CENTER
        }.also { root.addView(it) }
        if (iconFile.exists()) preview.setImageBitmap(BitmapFactory.decodeFile(iconFile.path))

        label("Ketukan per detik:"); cps = number("10")
        label("Tingkat kecocokan (0.5 - 1.0):"); conf = number("0.8")

        button("MULAI") { start() }
        button("BERHENTI") { stopService(Intent(this, CaptureService::class.java)) }

        setContentView(ScrollView(this).apply { addView(root) })

        if (Build.VERSION.SDK_INT >= 33)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 3)
    }

    override fun onResume() {
        super.onResume()
        status.text = if (ClickService.instance != null)
            "Aksesibilitas: AKTIF" else "Aksesibilitas: belum aktif"
    }

    private fun start() {
        if (!iconFile.exists()) { toast("Upload ikon dulu"); return }
        if (ClickService.instance == null) {
            toast("Aktifkan layanan aksesibilitas 'Icon Clicker' dulu")
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); return
        }
        val c = cps.text.toString().toDoubleOrNull()
        val t = conf.text.toString().toDoubleOrNull()
        if (c == null || c <= 0 || t == null || t < 0.5 || t > 1.0) {
            toast("Cek nilai ketukan/detik dan kecocokan"); return
        }
        val mgr = getSystemService(MediaProjectionManager::class.java)
        startActivityForResult(mgr.createScreenCaptureIntent(), 2)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data == null) return
        when (requestCode) {
            1 -> {
                val uri = data.data ?: return
                val bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
                if (bmp == null) { toast("Gambar tidak bisa dibaca"); return }
                iconFile.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
                preview.setImageBitmap(bmp)
                toast("Ikon tersimpan")
            }
            2 -> {
                val i = Intent(this, CaptureService::class.java)
                    .putExtra("code", resultCode)
                    .putExtra("data", data)
                    .putExtra("cps", cps.text.toString().toDouble())
                    .putExtra("conf", conf.text.toString().toDouble())
                startForegroundService(i)
                toast("Berjalan. Buka aplikasi target.")
            }
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
